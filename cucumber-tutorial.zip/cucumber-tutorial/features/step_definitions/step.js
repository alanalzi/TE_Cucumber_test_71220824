import { expect } from "chai";
import { Builder, By, until } from "selenium-webdriver";
import { Given, When, Then, setDefaultTimeout, After } from "@cucumber/cucumber";

setDefaultTimeout(40000);
let driver;

// Cleanup setelah setiap skenario
After(async function () {
  if (driver) {
    await driver.quit();
    driver = null;
  }
});

// === GIVEN ===
Given("the user is on the login page", async function () {
  driver = new Builder().forBrowser("chrome").build();
  await driver.get("https://www.saucedemo.com/");
  await driver.wait(until.elementLocated(By.id("login-button")), 10000);
});

// === WHEN ===
When("the user enters a valid username and password", async function () {
  await driver.findElement(By.id("user-name")).sendKeys("standard_user");
  await driver.findElement(By.id("password")).sendKeys("secret_sauce");
});

When("the user enters an invalid username and password", async function () {
  await driver.findElement(By.id("user-name")).sendKeys("invalid_user");
  await driver.findElement(By.id("password")).sendKeys("wrong_password");
});

When("the user clicks the login button", async function () {
  const loginButton = await driver.wait(until.elementLocated(By.id("login-button")), 8000);
  await loginButton.click();
});

// Tambahkan item ke keranjang
When("the user add item to the cart", async function () {
  const addBtn = await driver.wait(
    until.elementLocated(By.id("add-to-cart-sauce-labs-backpack")),
    8000
  );
  await addBtn.click();
});

// Buka halaman keranjang
When("the user views the cart page", async function () {
  const cartIcon = await driver.wait(until.elementLocated(By.className("shopping_cart_link")), 8000);
  await cartIcon.click();
  await driver.wait(until.elementLocated(By.xpath("//span[text()='Your Cart']")), 8000);
});

// Hapus item dari keranjang
When("the user remove item from the cart", async function () {
  const removeBtn = await driver.wait(
    until.elementLocated(By.id("remove-sauce-labs-backpack")),
    8000
  );
  await removeBtn.click();
});

// Klik menu burger
When("the user clicks the menu button", async function () {
  const menuButton = await driver.wait(until.elementLocated(By.id("react-burger-menu-btn")), 8000);
  await menuButton.click();
  await driver.sleep(1000); // tunggu animasi
  await driver.wait(until.elementLocated(By.id("logout_sidebar_link")), 8000);
});

// Klik tombol logout
When("the user clicks the logout button", async function () {
  const logoutButton = await driver.wait(
    until.elementIsVisible(driver.findElement(By.id("logout_sidebar_link"))),
    8000
  );
  await driver.wait(until.elementIsEnabled(logoutButton), 3000);
  await logoutButton.click();
});

// Klik gambar produk
When("the user clicks on a product image", async function () {
  const img = await driver.wait(until.elementLocated(By.id("item_4_img_link")), 8000);
  await img.click();
});

// === THEN ===
// Sukses login
Then("the user should see a success message", async function () {
  const message = await driver
    .wait(until.elementLocated(By.className("title")), 8000)
    .getText();
  expect(message.trim()).to.equal("Products");
});

// Gagal login
Then("the user should see a failed message", async function () {
  const errorMessage = await driver
    .wait(until.elementLocated(By.css("[data-test='error']")), 8000)
    .getText();
  expect(errorMessage.toLowerCase()).to.include("username and password");
});

// Item terlihat di halaman cart
Then("item should be seen in the item page", async function () {
  const cartItem = await driver.wait(
    until.elementLocated(By.css(".cart_item, .cart_list .cart_item")),
    8000
  );
  expect(cartItem).to.exist;

  const itemName = await driver.findElement(By.className("inventory_item_name")).getText();
  expect(itemName).to.equal("Sauce Labs Backpack");

  await driver.findElement(By.id("continue-shopping")).click();
  await driver.wait(until.elementLocated(By.className("shopping_cart_badge")), 5000);
  const cartBadge = await driver.findElement(By.className("shopping_cart_badge")).getText();
  expect(cartBadge).to.equal("1");
});

// ✅ PERBAIKAN: Item sudah tidak ada di keranjang
Then("item shouldn't be seen in the item page", async function () {
  await driver.wait(async () => {
    const items = await driver.findElements(By.css(".cart_item, .cart_list .cart_item"));
    return items.length === 0;
  }, 8000, "Item masih muncul di cart padahal seharusnya sudah dihapus");

  await driver.findElement(By.id("continue-shopping")).click();
  await driver.wait(until.elementLocated(By.className("title")), 5000);
  const cartBadges = await driver.findElements(By.className("shopping_cart_badge"));
  expect(cartBadges.length).to.equal(0);
});

Then("the user should be redirected to login page", async function () {
  // Tunggu tombol login muncul
  const loginButton = await driver.wait(until.elementLocated(By.id("login-button")), 10000);
  expect(await loginButton.isDisplayed()).to.be.true;

  // Cek URL yang fleksibel
  const currentUrl = await driver.getCurrentUrl();
  console.log("Current URL after logout:", currentUrl); // Debug log
  expect(currentUrl).to.match(/^https:\/\/www\.saucedemo\.com\/?$/);
});


// Halaman detail produk
Then("the user should see product details page", async function () {
  await driver.wait(until.elementLocated(By.className("inventory_details_name")), 8000);
  const backButton = await driver.findElement(By.id("back-to-products"));
  expect(backButton).to.exist;
});

// Informasi produk muncul
Then("the product information should be displayed", async function () {
  const productName = await driver.findElement(By.className("inventory_details_name")).getText();
  expect(productName).to.not.be.empty;

  const productDesc = await driver.findElement(By.className("inventory_details_desc")).getText();
  expect(productDesc).to.not.be.empty;

  const productPrice = await driver.findElement(By.className("inventory_details_price")).getText();
  expect(productPrice).to.include("$");

  const productImage = await driver.findElement(By.className("inventory_details_img"));
  expect(productImage).to.exist;
});